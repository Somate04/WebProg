<?php
    session_start();
    include_once("userstorage.php");
    include_once("pokemonstorage.php");
    $ps = new PokemonStorage();
    $us = new UserStorage();
    $buycard = $_GET["buycard"];
    $pokemon = $ps->findById($buycard);
    $admincards = $_SESSION["admin"]["cards"];

    if($_SESSION["currentUser"]["id"] !== "admin" && $_SESSION["currentUser"]["money"] >= $pokemon["price"] && count($_SESSION['currentUser']["cards"]) < 5 && ($key = array_search($buycard, $_SESSION["admin"]["cards"])) !== null){
        $_SESSION["currentUser"]["cards"][] = $buycard;
        array_splice($admincards, $key, 1);
        $newuser = [
            "username" => $_SESSION["currentUser"]["username"],
            "email" => $_SESSION["currentUser"]["email"],
            "password" => $_SESSION["currentUser"]["password"],
            "money" => $_SESSION["currentUser"]["money"] -= $pokemon["price"],
            "isAdmin" => false,
            "cards" => $_SESSION["currentUser"]["cards"],
            "id" => $_SESSION["currentUser"]["id"]
        ];
        $newadmin = [
            "username" => "admin",
            "email" => "admin@gmail.com",
            "password" => "admin",
            "money" => 2000,
            "isAdmin" => true,
            "cards" => $admincards,
            "id" => "admin"
        ];
        $us->update($_SESSION["currentUser"]["id"], $newuser);
        $us->update("admin", $newadmin);
        $_SESSION["admin"] = $newadmin;
        $_SESSION["currentUser"] = $newuser;
        print_r($_SESSION['currentUser']["cards"]);
    }
    header("Location: index.php");

?>