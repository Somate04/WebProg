<?php
    session_start();
    include_once("pokemonstorage.php");
    include_once("userstorage.php");
    $ps = new PokemonStorage();
    $us = new UserStorage();
    $pokemons = $ps->findAll();
    $users = $us->findAll();
    $found = false;
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IKémon | Home</title>
    <link rel="stylesheet" href="styles/main.css">
    <link rel="stylesheet" href="styles/cards.css">
</head>
<body>
    <header>
        <h1><a href="index.php">IKémon</a> > Home</h1>
        <div class="login">
        <form action="" method="post">
            <input type="text" placeholder="Username" name="username">
            <input type="password" placeholder="Password" name="password">
            <button type="submit" name="login">Login</button>
            <a href="registration.php">Sign up</a>
        </form>
        
            <?php
                if(isset($_POST["login"])){

                    $username = $_POST["username"];
                    $password = md5($_POST["password"]);
                    $s = json_decode(file_get_contents("users.json"), true);
                    foreach($s as $user => $v){
                        if($v["username"] === $_POST["username"] && ($v["password"] === md5($_POST["password"]) || "admin" === $_POST["password"] )){
                            $currentUser = $v;
                            $found = true;
                            //session_start();
                            $_SESSION["currentUser"] = $currentUser;
                            $_SESSION["username"] = $currentUser["username"];
                            
                            break;
                        }
                    }
                    if(!$found){
                        echo "No such username and password combination was found!";
                    }
                }
                $_SESSION["admin"] = $us->findById("admin");
                if(isset($_SESSION["currentUser"])){
                    echo '<h1>Welcome, <a href="user-details.php">'.$_SESSION["username"].'</a>!</h1><br><p>💳: '.$_SESSION["currentUser"]['money'].' 🥮</p>';    
                    echo '<a href="logout.php">Log out</a>';
                }
            ?>
        <a href="admin.php" style="visibility: <?php if(isset($_SESSION["currentUser"]) && $_SESSION["currentUser"]["id"] === "admin"){echo "visible;";}else{echo "hidden;";}?>">Create card</a>
    </div>
    </header>
    <div id="content">
        <div id="filter">
            <form action="" method="post">
                <select type="text" name="filterType">
                    <option value="all">All</option>
                    <option value="electric">Electric</option>
                    <option value="fire">Fire</option>
                    <option value="grass">Grass</option>
                    <option value="water">Water</option>
                    <option value="bug">Bug</option>
                    <option value="normal">Normal</option>
                    <option value="poison">Poison</option>
                </select>
                <input type="submit" value="Filter" id="filter-button"></input>
            </form>
        </div>
        <div id="card-list">
            <?php if(!isset($_POST["filterType"]) || $_POST["filterType"] === "all") : ?>
            <?php foreach($pokemons as $pokemon) : ?>
                <div class="pokemon-card">
                    <div class="image clr-<?= $pokemon['type'] ?>">
                    <img src="<?= $pokemon['image']?>" alt="">
            </div>
            <div class="details">
                <h2><a href="details.php?id=<?=$pokemon['id'] ?>"><?=$pokemon['name'] ?></a></h2>
                <span class="card-type"><span class="icon">🏷</span> <?= $pokemon['type'] ?></span>
                <span class="attributes">
                        <span class="card-hp"><span class="icon">❤</span> <?= $pokemon['hp'] ?></span>
                        <span class="card-attack"><span class="icon">⚔</span> <?= $pokemon['attack'] ?></span>
                        <span class="card-defense"><span class="icon">🛡</span> <?= $pokemon['defense'] ?></span>
                    </span>
            </div>
            <a href="buy.php?buycard=<?php echo $pokemon["id"];?>" style="visibility: <?php if(isset($_SESSION["currentUser"]) && in_array($pokemon["id"], $_SESSION["admin"]["cards"])){echo "visible;";}else{echo "hidden;";}?>"><div class="buy">
                    <span class="card-price"><span class="icon">🛒</span> <?= $pokemon['price'] ?></span>
                </div></a>
            </div>
            <?php endforeach ?>
            <?php endif ?>
            <?php if(isset($_POST["filterType"])) : ?>
                <?php foreach($pokemons as $pokemon) : ?>
                    <?php if($pokemon["type"] === $_POST["filterType"]) : ?>
                    <div class="pokemon-card">
                        <div class="image clr-<?= $pokemon['type'] ?>">
                        <img src="<?= $pokemon['image']?>" alt="">
                </div>
                <div class="details">
                    <h2><a href="details.php?id=<?=$pokemon['id'] ?>"><?=$pokemon['name'] ?></a></h2>
                    <span class="card-type"><span class="icon">🏷</span> <?= $pokemon['type'] ?></span>
                    <span class="attributes">
                            <span class="card-hp"><span class="icon">❤</span> <?= $pokemon['hp'] ?></span>
                            <span class="card-attack"><span class="icon">⚔</span> <?= $pokemon['attack'] ?></span>
                            <span class="card-defense"><span class="icon">🛡</span> <?= $pokemon['defense'] ?></span>
                        </span>
                </div>
                <a href="buy.php?buycard=<?php echo $pokemon["id"];?>" style="visibility: <?php if(isset($_SESSION["currentUser"]) && in_array($pokemon["id"], $_SESSION["admin"]["cards"])){echo "visible;";}else{echo "hidden;";}?>"><div class="buy">
                    <span class="card-price"><span class="icon">🛒</span> <?= $pokemon['price'] ?></span>
                </div></a>
                </div>
                <?php endif ?>
            <?php endforeach ?>
            <?php endif ?>
        </div>
    </div>
    <footer>
        <p>IKémon | ELTE IK Webprogramozás</p>
    </footer>
</body>

</html>