<?php
    session_start();
    include_once("pokemonstorage.php");
    $ps = new PokemonStorage();
    $pokemons = $ps->findAll();

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IKémon | User details</title>
    <link rel="stylesheet" href="styles/main.css">
    <link rel="stylesheet" href="styles/cards.css">
</head>

<body>
    <header>
        <h1><a href="index.php">IKémon</a> > User details</h1>
        <p>🆔: <?php echo $_SESSION["currentUser"]["username"]; ?></p>
        <p>📧: <?php echo $_SESSION["currentUser"]["email"]; ?></p>
        <p><?php echo "💳: ".$_SESSION["currentUser"]["money"]." 🥮"; ?></p>
    </header>
    <div id="content">
        <div id="card-list">
            <?php foreach($_SESSION["currentUser"]["cards"] as $card){
                        echo '<div class="pokemon-card">
                                <div class="image clr-'.$ps->findById($card)["type"].'">
                                <img src="'.$ps->findById($card)["image"].'" alt="">
                                </div>
                             <div class="details">
                                <h2><a href="details.php?id='.$card.'">'.$ps->findById($card)['name'].'</a></h2>
                                <span class="card-type"><span class="icon">🏷</span>'.$ps->findById($card)['type'].'</span>
                                <span class="attributes">
                                    <span class="card-hp"><span class="icon">❤</span>'.$ps->findById($card)['hp'].'</span>
                                    <span class="card-attack"><span class="icon">⚔</span>'.$ps->findById($card)['attack'].'</span>
                                    <span class="card-defense"><span class="icon">🛡</span>'.$ps->findById($card)['defense'].'</span>
                                    </span>
                             </div>
                             <a href=sell.php?sellcard='.$_SESSION["cardid"] = $ps->findById($card)["id"].'>
                            <div class="buy">
                            <span class="card-price"><span class="icon">💰</span>'.$ps->findById($card)['price']*0.9.'</span>
                            </div></a></div>';
                    }
            ?>
    </div>
    </div>
    <footer>
        <p>IKémon | ELTE IK Webprogramozás</p>
    </footer>
</body>

</html>