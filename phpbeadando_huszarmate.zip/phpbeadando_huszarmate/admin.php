<?php
    include_once("pokemonstorage.php");
    $ps = new PokemonStorage();

    $pokemons = $ps->findAll();
    $length = 9;

    if(isset($_POST['id']) && isset($_POST['hp']) && isset($_POST['attack']) && isset($_POST['defense']) && isset($_POST['price']) && 
    !empty($_POST['id']) && !empty($_POST['hp']) && !empty($_POST['attack']) && !empty($_POST['defense']) && !empty($_POST['price'])){
        $samepokemon = $ps->findById($_POST["id"]);
        $name = $samepokemon["name"];
        $type = $samepokemon["type"];
        $hp = $_POST["hp"];
        $attack = $_POST["attack"];
        $defense = $_POST["defense"];
        $price = $_POST["price"];
        $description = $samepokemon["description"];
        $image = $samepokemon["image"];
        $newpokemon = [
            "name" => $name,
            "type" => $type,
            "hp" => $hp,
            "attack" => $attack,
            "defense" => $defense,
            "price" => $price,
            "description" => $description,
            "image" => $image,
        ];
        $ps->add($newpokemon);
        header("Location: index.php");
        //exit();
    }



?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IKémon | Admin</title>
    <link rel="stylesheet" href="styles/main.css">
    <link rel="stylesheet" href="styles/details.css">
</head>

<body>
    <header>
        <h1><a href="index.php">IKémon</a> >Admin</h1>
    </header>
    <div id="content">
        <form novalidate method="post" action="">
            <label for="id">Name:</label>
                <select type="text" name="id">
                    <?php foreach($pokemons as $pokemon) : ?>
                        <option value="<?=$pokemon["id"]?>"><?=$pokemon["name"]?></option>
                    <?php endforeach ?>
                </select>   
            <br>
            <label for="hp">HP:</label>
            <input type="number" name="hp" id="hp">
            <?php
                if(!isset($_POST["hp"]) || empty($_POST["hp"])){
                    echo "Health points are required!";
                }
                else if($_POST["hp"] < 1){
                    echo "Health points must be at least 1!";
                }
            ?> 
            <br>
            <label for="attack">Attack:</label>
            <input type="number" name="attack" id="attack">
            <?php
                if(!isset($_POST["attack"]) || empty($_POST["attack"])){
                    echo "Attack points are required!";
                }
                else if($_POST["attack"] < 1){
                    echo "Attack points must be at least 1!";
                }
            ?> 
            <br>            
            <label for="defense">Defense:</label>
            <input type="number" name="defense" id="defense">
            <?php
                if(!isset($_POST["defense"]) || empty($_POST["defense"])){
                    echo "Defense points are required!";
                }
                else if($_POST["defense"] < 1){
                    echo "Defense points must be at least 1!";
                }
            ?> 
            <br>            
            <label for="price">Price:</label>
            <input type="number" name="price" id="price">
            <?php
                if(!isset($_POST["price"]) || empty($_POST["price"])){
                    echo "Price points are required!";
                }
                else if($_POST["price"] < 1){
                    echo "Price points must be at least 1!";
                }
            ?> 
            <br>
            <input type="submit" value="Add Card">            
        </form>
    </div>
    <footer>
        <p>IKémon | ELTE IK Webprogramozás</p>
    </footer>
</body>
</html>