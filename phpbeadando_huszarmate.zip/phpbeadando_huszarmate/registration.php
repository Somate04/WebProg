<?php
    session_start();
    include_once("userstorage.php");
    $us = new UserStorage();

    $users = $us->findAll();
    $usernames = [];
    $starterMoney = 2000;
    if(isset($_POST["username"]) && isset($_POST["email"]) && isset($_POST["password"]) && isset($_POST["password2"]) &&
    !empty($_POST["username"]) && !empty($_POST["email"]) && !empty($_POST["password"]) && !empty($_POST["password2"])){
        $username = trim($_POST["username"]);
        $email = trim($_POST["email"]);
        $password = trim($_POST["password"]);
        $password2 = trim($_POST["password2"]);
        foreach($users as $user){
            array_push($usernames,$user["username"]);
        }
        if($password === $password2 && !in_array($username, $usernames) && filter_var($email, FILTER_VALIDATE_EMAIL)){
            $newuser = [
                "username" => $username,
                "email" => $email,
                "password" => md5($password),
                "money" => $starterMoney,
                "isAdmin" => false,
                "cards" => []
            ];
            $us->add($newuser);
            $users = $us->findAll();
            $_SESSION["currentUser"] = end($users);
            $_SESSION["username"] = $username;
            header("Location: index.php");
        }

    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ikémon | Registration</title>
    <link rel="stylesheet" href="styles/main.css">
</head>
<body>
<header>
        <h1><a href="index.php">IKémon</a> > Registration</h1>
    </header>
    <div id="content">
        <form action="" method="post">
            <label for="username">Username: </label>
            <input type="text" name="username" id="username" value="<?php echo isset($_POST['username']) ? $_POST['username'] : '' ?>">
            <?php
                if(!isset($_POST["username"]) || empty($_POST["username"])){
                    echo "Username is required!";
                }
                else if(in_array($_POST["username"], $usernames)){
                    echo "Username must be unique!";
                }
            ?>
            <br>
            <label for="email">Email: </label>
            <input type="text" name="email" id="email" value="<?php echo isset($_POST['email']) ? $_POST['email'] : '' ?>">
            <?php
                if(!isset($_POST["email"]) || empty($_POST["email"])){
                    echo "Email address is required!";
                }
                else if(!filter_var($_POST["email"], FILTER_VALIDATE_EMAIL)){
                    echo "Wrong email format!";
                }
            ?>
            <br>
            <label for="password">Password: </label>
            <input type="password" name="password" id="password">
            <?php
                if(!isset($_POST["password"]) || empty($_POST["password"])){
                    echo "Password is required!";
                }
            ?>
            <br>
            <label for="password2">Confirm password: </label>
            <input type="password" name="password2" id="password2">
            <?php
                if(!isset($_POST["password2"]) || empty($_POST["password2"]) || ($_POST["password"] != $_POST["password2"])){
                    echo "Passwords do not match!";
                }
            ?>
            <br>
            <input type="submit" value="Confirm">
        </form>
    </div>
    <footer>
        <p>IKémon | ELTE IK Webprogramozás</p>
    </footer>
</body>
</html>